<p align="center">
	<img src="https://github.com/cstamant/close-figma-tabs/blob/46c518122990cf68f527adf01725297fde276934/icons/icon128.png">
</p>

# close-figma-tabs
Chrome extension to close figma tabs after they open in the desktop app

## Installation
1. Download latest release
2. Extract to somewhere on your drive
3. Open [chrome extension page](chrome://extensions/)
4. Enable developer mode in the top right
5. Click load unpacked
6. Navigate to close-figma-tabs folder on your drive and open